# Caustryn coherent portable experiment

This is synthetic/model-conditioned single-point radio evidence, not a hardware
measurement, room reconstruction, pose tracker or certificate of coherence.

Use CPython 3.12 or newer with an isolated virtual environment. The tested lock is:
    python -m pip install -r requirements.lock
Then run from any working directory:
    python /path/to/bundle/rerun.py --output NEW-result.json
Omit --output to print new JSON to stdout. Existing outputs are refused. result.json
is the calculation freshly recomputed at export; the runner never reads it as fit
input. A rerun may differ in elapsed seconds or minor numerical details.

When present, allowed_poses_m.json and plan.json record a fresh training-only planning calculation.
The planner can be replayed separately with `python rerun.py --plan`.
training.json is the only fitting input. If supplied, validation.json describes
known held receiver positions and IQ tied to the exact canonical training hash.
The held evaluation fits training again, predicts every retained candidate with its
training-fitted complex gains, and neither refits gains/location nor selects/removes
mirror modes using held IQ. Optional context.json is supplied UNVERIFIED context,
never passed to inference. Its presence does not authenticate simulated or measured
provenance. The generator and truth are not required for blind calculations.

Unknown complex gains are assumed constant across receiver positions separately
for each hardware pair and frequency. That assumption and known receiver geometry
are trusted, not established by a small residual. Pose-dependent hardware response
can counterfeit another scene and also pass held-position prediction. Retained
modes are found finite-search candidates, not all mathematical solutions or a
uniqueness/confidence guarantee. Inspect every candidate and the recorded warnings.

SHA256SUMS.json covers all included file bytes except itself. manifest.json records
canonical finite-JSON identities with sorted keys/compact separators. Integral
floats and negative zero share identity with the corresponding integers, matching
browser JSON round trips while the scientific validator still rejects booleans.
The runner
checks these before importing calculation code. They detect changes against this
manifest; they are not signatures or proof of authenticity.

Actual Caustryn source (the compatible phaseglass package), MIT LICENSE with dependency terms are included.
NumPy/SciPy are installed separately under their own licenses. Installing requires
an available package source or local wheel cache; recalculation uses no network.
No account, credential, paid API, telemetry or original scene is required.
