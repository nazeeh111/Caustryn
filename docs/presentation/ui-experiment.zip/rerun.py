# SPDX-License-Identifier: MIT
"""Verify the frozen bundle and rerun blind training/held prediction from anywhere."""
import argparse
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import sys

def semantic_numbers(value):
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError("Nonfinite JSON number")
        return int(value) if value.is_integer() else value
    if type(value) is list:
        return [semantic_numbers(item) for item in value]
    if type(value) is dict:
        return {key: semantic_numbers(item) for key, item in value.items()}
    return value

def canonical(value):
    return hashlib.sha256(json.dumps(semantic_numbers(value), sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description="Verify and recompute the included blind coherent experiment")
    parser.add_argument("--output", help="New result JSON; existing files are never overwritten. Default: stdout.")
    parser.add_argument("--plan", action="store_true", help="Recompute the training-only pose plan")
    args = parser.parse_args()
    if sys.implementation.name != "cpython" or sys.version_info < (3, 12):
        raise ValueError("This dependency lock requires CPython 3.12 or newer")
    root = Path(__file__).resolve().parent
    checksums = json.loads((root / "SHA256SUMS.json").read_bytes())
    if type(checksums) is not dict or not checksums:
        raise ValueError("Checksum manifest must be a nonempty object")
    required = {"training.json", "result.json", "manifest.json", "rerun.py",
                "requirements.lock", "LICENSE",
                "phaseglass/coherent.py", "phaseglass/cli.py", "phaseglass/__init__.py"}
    if not required <= set(checksums):
        raise ValueError("Checksum manifest omits required calculation files")
    size = 0
    for name, expected in checksums.items():
        relative = Path(name)
        if type(name) is not str or relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
            raise ValueError("Unsafe checksum path")
        path = root / relative
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError("Checksum path leaves bundle")
        data = path.read_bytes()
        size += len(data)
        if size > 4 * 1024 * 1024:
            raise ValueError("Portable contents exceed 4 MiB")
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError("Checksum mismatch: " + name)
    manifest = json.loads((root / "manifest.json").read_bytes())
    if manifest.get("schema") != "phaseglass-coherent-portable-v1":
        raise ValueError("Unsupported portable schema")
    for key, filename in (("training", "training.json"), ("validation", "validation.json"),
                          ("context", "context.json"), ("result", "result.json"),
                          ("allowed_poses_m", "allowed_poses_m.json"), ("plan", "plan.json")):
        if key not in manifest["canonical_sha256"]:
            continue
        if filename not in checksums:
            raise ValueError("Checksum manifest omits " + filename)
        value = json.loads((root / filename).read_bytes())
        if canonical(value) != manifest["canonical_sha256"][key]:
            raise ValueError("Canonical input/result identity mismatch: " + filename)
    for dependency, expected in (("numpy", "2.3.5"), ("scipy", "1.18.1")):
        try:
            actual = importlib.metadata.version(dependency)
        except importlib.metadata.PackageNotFoundError:
            raise ValueError("Missing dependency " + dependency + "; install requirements.lock") from None
        if actual != expected:
            raise ValueError("Dependency lock mismatch: " + dependency + "=" + actual + "; expected " + expected)
    # Import our own source first. Context/result are never inference arguments.
    sys.path.insert(0, str(root))
    from phaseglass.cli import main as cli_main
    command = "sweep-plan" if args.plan else ("sweep-evaluate" if "validation" in manifest["canonical_sha256"] else "sweep-solve")
    if args.plan and "allowed_poses_m" not in manifest["canonical_sha256"]:
        raise ValueError("No allowed poses in this bundle")
    arguments = [command, str(root / "training.json")]
    if command == "sweep-evaluate":
        arguments += ["--validation", str(root / "validation.json")]
    if command == "sweep-plan":
        arguments += ["--allowed-poses", str(root / "allowed_poses_m.json")]
    if args.output:
        output = Path(args.output)
        if output.exists() or output.is_symlink():
            raise ValueError("Output already exists; choose a new result path")
        arguments += ["--output", str(output)]
    return cli_main(arguments)

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, TypeError, OSError) as error:
        print("coherent replay: " + str(error), file=sys.stderr)
        raise SystemExit(2)
